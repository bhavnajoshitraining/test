package spring.mvcweb.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class config extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override
	protected Class<?>[] getRootConfigClasses() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		Class[] c= {myConfig.class};
		// TODO Auto-generated method stub
		return c;
	}

	@Override
	protected String[] getServletMappings() {
		// TODO Auto-generated method stub
		String[] s= {"/"};
		return s;
	}

}
