package spring.mvcweb.service;

import spring.mvcweb.model.User;
import spring.mvcweb.model.login;

public interface UserService {
	 int register(User user);
	  User validateUser(login login);
}
