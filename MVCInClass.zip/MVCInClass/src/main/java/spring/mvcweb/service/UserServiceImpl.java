package spring.mvcweb.service;

import org.springframework.beans.factory.annotation.Autowired;

import spring.mvcweb.dao.UserDao;
import spring.mvcweb.model.User;
import spring.mvcweb.model.login;

public class UserServiceImpl implements UserService {

	@Autowired
	public UserDao  userdao;
	public int register(User user) {
		userdao.register(user);
		return 0;
	}

	public User validateUser(login login) {
		userdao.validateUser(login);
		return null;
	}
	
}
