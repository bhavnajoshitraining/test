package spring.mvcweb.dao;

import spring.mvcweb.model.User;
import spring.mvcweb.model.login;

public interface UserDao {
	void register(User user);
	User validateUser(login login);
}
