package com.inher;

public class Demo {
	public static void main(String[] args) {
           Honda bike = new Honda();
           bike.display();
	}
}
