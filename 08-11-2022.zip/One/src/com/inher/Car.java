package com.inher;

public class Car extends Vehicle {
    int price =100;
    public void run() {
		System.out.println("i am in car!!! ");
	}
}
