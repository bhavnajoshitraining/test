package com.inher;

public class Vehicle {
	protected String modelName = "ford a50s";
	public void display() {
		System.out.println("i am in Vehicle!!! ");
	}
}
