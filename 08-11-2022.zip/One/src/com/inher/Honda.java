package com.inher;

public class Honda extends Bike {
	public void jump() {
		System.out.println("i am in honda!!! ");
	}
	public void display() {
		System.out.println("i am in Honda display!!! ");
	}
}
