package com.inher;

public class Bike extends Vehicle {
	private String brand = "Tata";
	public void shows() {
		System.out.println("i am in Bike!!! ");
	}
	public void display() {
		System.out.println("i am in bike display!!! ");
	}
}
