package com.tests;

public class FinalHashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
