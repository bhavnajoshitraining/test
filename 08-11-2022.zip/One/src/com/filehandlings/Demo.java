package com.filehandlings;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Scanner;

public class Demo {

	public static void main(String[] args) throws IOException{// TODO Auto-generated method stub
		
		Scanner in = new Scanner(System.in);
		
		String s = in.nextLine();
		System.out.println(s);
		
		int a = in.nextInt();
		System.out.println(a);
		
		System.out.println("now enter float");
		float f = in.nextFloat();
		System.out.println(f);
//		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//		String nameString = reader.readLine();
//		System.out.println(nameString);
	}
}
