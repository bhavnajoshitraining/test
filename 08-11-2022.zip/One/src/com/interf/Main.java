package com.interf;

public class Main {

	public static void main(String[] args) {
		Dog moti = new Dog();
		moti.run();
		moti.eat();
		moti.breath();
		moti.sound();
		
	}

}
