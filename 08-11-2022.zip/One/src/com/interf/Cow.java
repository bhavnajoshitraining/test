package com.interf;

public class Cow implements Animal {

	@Override
	public void sound() {
		System.out.println("bowwwwww");

	}

	@Override
	public void eat() {
		System.out.println("I am cow, i eat grass!!");
	}

}
