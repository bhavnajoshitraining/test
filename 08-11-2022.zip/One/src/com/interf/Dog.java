package com.interf;

public class Dog implements Living, Animal {

	@Override
	public void sound() {
		System.out.println("bho-bho");

	}

	@Override
	public void eat() {
		System.out.println("I eat everything i get");

	}

	@Override
	public void breath() {
		System.out.println("dhak dhak!!");

	}

	@Override
	public void run() {
		System.out.println("I run fast");
	}

}
