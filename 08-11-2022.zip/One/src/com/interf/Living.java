package com.interf;

public interface Living {
	public void breath();
	public void run();
}
