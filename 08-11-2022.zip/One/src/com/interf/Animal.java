package com.interf;

public interface Animal {
	public void sound();
	public void eat();
}
