package com.collec;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Col {

	public static void main(String[] args) {
			
		Double a = new Double(222.444444);
		Long l = new Long(785759333);
		
		System.out.println(a.equals(222.444444));
	}
}
