package com.my;

public class Calculations {

	public void sum(int... a) {
		System.out.println("number of arguments "+a.length);
		int b=0;
		for(int i: a) {
		  b=b+i;
		}
		  System.out.println(b);
	}
}
