package com.demo;

import java.util.Iterator;

public class Calculator {
	
	static void sum(int... a) {
		System.out.println("number of arguments "+a.length);
		
		for(int i: a) {
		    System.out.println(i+" ");
		}
	}
}
