package com.demo;

public class Test<T> {
	T obj;

	public Test(T obj) {
		super();
		this.obj = obj;
	}

	public T getObj() {
		return obj;
	}
}
