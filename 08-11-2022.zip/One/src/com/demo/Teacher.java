package com.demo;

public class Teacher {
	int id;
	String name;
	String address;
	
//	public Teacher() {
//	}

	public Teacher(int id, String name, String address) {
		this.id = id;
		this.name = name;
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	//defination of method
	public void sayHello() {
		System.out.println("Hello "+this.name);
	}
}
