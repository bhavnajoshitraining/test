package com.demo;
import com.my.Calculations;
public class Main {
	public static void main(String[] args) {
		Test<Integer> aTest = new Test<Integer>(11);
		System.out.println(aTest.getObj());
		
		Test<String> bTest = new Test<String>("demo");
		System.out.println(bTest.getObj());
		
		
	
	}
}
