package com.strdemo;

public class Demo {

	public static void main(String[] args) {
	 StringBuffer st = new StringBuffer("Hello");
	 st.append(" world");
	 System.out.println(st);
	}

}
