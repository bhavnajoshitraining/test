package com.dead;

public class Util {

	static void sleep(long milis) {
		try {
			Thread.sleep(milis);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
