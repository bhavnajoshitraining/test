package com.dead;

public class Shared {

	synchronized void test1(Shared s) {
		System.out.println("First Test Begin-1");
		Util.sleep(1000);
		
		s.test2();
		System.out.println("First Test End");
	}
	
	synchronized void test2() {
		System.out.println("Second Test Begin-2");
		Util.sleep(1000);
		System.out.println("Second Test End");
	}
}
