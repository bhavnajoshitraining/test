package com.ser;

import java.io.Serializable;

public class Student implements Serializable{

	int id;
	String nameString ;
	
	public Student(int id, String nameString) {
		super();
		this.id = id;
		this.nameString = nameString;
	}
}
