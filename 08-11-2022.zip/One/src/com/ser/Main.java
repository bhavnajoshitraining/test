package com.ser;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		try {
			Student student = new Student(1, "anu");
			FileOutputStream fOutputStream = new FileOutputStream("src/a.txt");
			ObjectOutputStream out = new ObjectOutputStream(fOutputStream);
			out.writeObject(student);
			out.flush();
			out.close();
			System.out.println("Done successfully");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
