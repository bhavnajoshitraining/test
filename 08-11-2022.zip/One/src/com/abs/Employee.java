package com.abs;

abstract class Employee {

	abstract void Developcode();
}
