package com.abs;

public class Developer extends Employee {

	@Override
	void Developcode() {
		System.out.println("Writing in JAVA!!");

	}

	public static void main(String[] args) {
		Employee employee = new Developer();
		employee.Developcode();
	}

}
