package com.exc;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
	
		int a=1;
		Integer b = Integer.valueOf(a);//boxing
		System.out.println(b);
		int c = b.intValue(); //unboxing
		System.out.println(c);
	}
}
