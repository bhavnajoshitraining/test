package com.proco;

public class Main {

	public static void main(String[] args) {
		Shop stopShop = new Shop();
		Producer p = new Producer(stopShop, 1);
		Consumer c = new Consumer(stopShop, 1);
		
		p.start();
		c.start();
	}

}
