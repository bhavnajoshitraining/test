package com.proco;

public class Consumer extends Thread {

	private Shop shop;
	private int no;
	
	public Consumer(Shop shop, int no) {
		super();
		this.shop = shop;
		this.no = no;
	}
	
	public void run() {
		int value =0;
		for(int i=1;i<10;i++) {
			value = shop.get();
			System.out.println("Consumed "+this.no + "got "+ value);
		}
	}
}
