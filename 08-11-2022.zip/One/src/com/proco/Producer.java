package com.proco;

public class Producer extends Thread {

	private Shop shop;
	private int no;
	
	public Producer(Shop shop, int no) {
		super();
		this.shop = shop;
		this.no = no;
	}
	
	public void run() {
		for(int i=1;i<10;i++) {
			shop.put(i);
			System.out.println("Producer value "+this.no +"put: "+i);
			
			try {
				sleep((int)(Math.random()*100+1));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
