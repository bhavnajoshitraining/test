package com.multi;

public class Runnab implements Runnable {

	@Override
	public void run() {
		try {
			System.out.println( "Thread "+ Thread.currentThread().getId()+" is running now");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
