package com.multi;

public class Mult extends Thread {

	public void run() {
		try {
			System.out.println( "Thread "+ Thread.currentThread().getId()+" is running now");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
