package com.multi;

public class MyThread implements Runnable {

	String message;
	
	
	public MyThread(String msg) {
		
		message = msg;
	}


	@Override
	public void run() {
		//System.out.println("Message is "+message);
			System.out.println("a1");
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("a2");
	}
	}
