package com.multi;

public class Main {

	public static void main(String[] args) {
		MyThread obj1 = new MyThread("I am Obj1");
		MyThread obj2 = new MyThread("I am Obj2");
		
		Thread a = new Thread(obj1);
		Thread b = new Thread(obj2);
		
		a.start();
		try {
			a.join();
		} catch (Exception e) {
			// TODO: handle exception
		}
		b.start();
		
		
//		System.out.println(a.isAlive());
//		System.out.println(b.isAlive());
}
}