package com.demo.jaxrsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JaxrsdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
