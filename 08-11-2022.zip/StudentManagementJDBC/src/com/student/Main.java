package com.student;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.student.management.Student;
import com.student.management.StudentDao;

public class Main {

	public static void main(String[] args) throws IOException{

		System.out.println("Welcome to student management system!!!!");
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		while(true) {
			System.out.println("Press 1 to Add Student");
			System.out.println("Press 2 to Delete Student");
			System.out.println("Press 3 to Display Student");
			System.out.println("Press 4 to Update Student");
			System.out.println("Press 5 to exit Student Management application");
			
			int c = Integer.parseInt(br.readLine());
			
			System.out.println("You Entered:- "+c);
			
			switch (c) {
			case 1: {
				System.out.println("Enter the name of student:-");
				String name = br.readLine();
				
				System.out.println("Enter the phone number of student:-");
				String phone = br.readLine();
				
				System.out.println("Enter the city of student:-");
				String city = br.readLine();
				
				Student student = new Student(name,phone,city);
				System.out.println(student);
				
				boolean result = StudentDao.insertStudentToDB(student);
				
				if (result) {
					System.out.println("Successfully inserted");
				}else {
					System.out.println("something went wrong");
				}
				break;
			}
			
			case 5:
				System.exit(0);
				break;
			default:
				throw new IllegalArgumentException("Unexpected value: " + c);
			}
		}

	}

}
