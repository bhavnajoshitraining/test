package com.student.management;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class StudentDao {

	public static boolean insertStudentToDB(Student student) {
	
		boolean f=false;
		
		try {
			Connection connection = CP.createConnection();
			
			String query = "insert into student(sname, sphone, scity) values(?,?,?)";
			PreparedStatement p= connection.prepareStatement(query);
			p.setString(1, student.getStudentName());
			p.setString(2, student.getStudentPhone());
			p.setString(3, student.getStudentCity());
			
			p.executeUpdate();
			f=true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return f;
	}
}
