package com.student.management;

import java.sql.Connection;
import java.sql.DriverManager;

public class CP {

	static Connection connection;
	
	public static Connection createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/techera";
			String user = "root";
			String password = "MyNewPass";
			
			connection = DriverManager.getConnection(url,user,password);
		} catch (Exception e) {
			e.printStackTrace();
			connection=null;
		}
		return connection;
	}
}
