package JUNITPack;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class JUnitExample {
	
		@BeforeEach
	    public void set() {
	        System.out.println("BeforeEach");
	    }
		
		@AfterEach
		public void goes() {
			System.out.println("@AfterEach");
		}
	    
		@Test
		void test2() {
			System.out.println("TestCase1");
			String s = "BhavnaJoshi";
			assertEquals("BhavnaJoshi", s);
		}


}
