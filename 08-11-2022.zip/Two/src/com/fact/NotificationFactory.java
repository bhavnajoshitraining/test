package com.fact;

public class NotificationFactory {

	public Notification createNote(String channel) {
		if(channel==null|| channel.isEmpty()) {
			return null;
		}
		
		switch (channel){
		case "SMS": 
			return new SMS();
		case "EMAIL":
			return new Email();
		case "PUSH":
			return new PushNotification();
		default:
			throw new IllegalArgumentException("Unexpected value: " + channel);
		}
	}
}
