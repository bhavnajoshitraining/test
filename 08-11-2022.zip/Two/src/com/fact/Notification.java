package com.fact;

public interface Notification {
	void notifyUser();
}
