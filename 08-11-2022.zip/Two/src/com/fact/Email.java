package com.fact;

public class Email implements Notification {

	@Override
	public void notifyUser() {
		System.out.println("Hello Email---------------");

	}

}
