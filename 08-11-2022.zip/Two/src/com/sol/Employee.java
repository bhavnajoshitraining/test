package com.sol;

public class Employee {
	private int id;
	private String name;
	private int age;
	private static int nextId=1;
	
	public Employee(String name, int age) {
		this.id = nextId++;
		this.name = name;
		this.age = age;
	}
	
	public void show() {
		System.out.println("Employee [id=" + id + ", name=" + name + ", age=" + age );
	}
	
	public void showNextId() {
		System.out.println("next id is "+nextId);
	}
	
	protected void finalize() {
		--nextId;
	}
}
