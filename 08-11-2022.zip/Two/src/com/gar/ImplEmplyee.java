package com.gar;

public class ImplEmplyee {

	public static void main(String[] args) {
		Employee e1 = new Employee("Anu", 20);
		Employee e2 = new Employee("shanu", 10);
		Employee e3 = new Employee("chanu", 30);

		e1.show();
		e2.show();
		e3.show();
		
		e1.showNextId();
		e2.showNextId();
		e3.showNextId();
		
		{
			Employee x = new Employee("bAnu", 20);
			Employee y = new Employee("mhanu", 10);
			
			x.show();
			y.show();
			
			x.showNextId();
			y.showNextId();
		}
		
		e1.showNextId();
	}
}
