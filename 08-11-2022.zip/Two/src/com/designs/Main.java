package com.designs;

public class Main {

	public static void main(String[] args) {
		Singleton singleton;
		singleton = Singleton.getInstance();
		singleton.display();

	}

}
