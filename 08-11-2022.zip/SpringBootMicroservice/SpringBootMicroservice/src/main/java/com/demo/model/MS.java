package com.demo.model;

public class MS {

	private int min;
	private int max;
	
	public MS() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MS(int min, int max) {
		super();
		this.min = min;
		this.max = max;
	}
	public int getMin() {
		return min;
	}
	public void setMin(int min) {
		this.min = min;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
}
